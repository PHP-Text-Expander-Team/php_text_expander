--
-- Database: `expander`
--
CREATE DATABASE IF NOT EXISTS `expander` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `expander`;

-- --------------------------------------------------------

--
-- Table structure for table `snippets`
--

CREATE TABLE `snippets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `shortcut` varchar(255) DEFAULT NULL,
  `text` text,
  `number_of_variables` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `snippets`
--

INSERT INTO `snippets` (`id`, `shortcut`, `text`, `number_of_variables`) VALUES
(7, 'testing', 'text', NULL),
(8, ';test', 'This is a test of our program: ||||@!!@1@!!@||||! My name is ||||@!!@2@!!@||||, and blah blah ||||@!!@1@!!@||||.', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `snippets`
--
ALTER TABLE `snippets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `snippets`
--
ALTER TABLE `snippets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
